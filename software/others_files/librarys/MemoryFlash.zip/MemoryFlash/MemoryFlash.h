#ifdef MEMORYFLASH_H_INCLUDED
#define MEMORYFLASH_H_INCLUDED

class MemoryFlash{
    public:
        MemoryFlash();
        void writeString(char add, String content);
        String read_String(char add);
}