/*
    Autor: Matheus Gois Vieira
    Março de 2020
    Obs: Utilize um conversor RS232-TTL, conecte:

*/

#include "ScaleElgin.h"
#include "string.h"
#include "Arduino.h"

char vector[] = {0, 0, 0, 0, 0, 0, 0};
char peso_aux[] = {0, 0, 0, 0, 0, 0};
int value;
int n = 7;
String g = "g";

ScaleElgin::ScaleElgin(String peso){
    weight = peso;
    pinMode(13,OUTPUT);
}

String ScaleElgin::readScale() {
  
  while (1) {
    // Send "5" for scale
    Serial.write(5);

    //If there is an answer do...
    if (Serial.available() > 0) {
      // lê o dado recebido:
      for (int c = 0; c < n; c++) {

        value = Serial.read();

        switch (value) {
          case -1:
            vector[c] = '.';
            break;
          case 2:
            break;
          case 3:
            vector[c] = 'k';
            break;
          default:
            vector[c] = value;
        }
      }

      if (vector[n - 1] == 'k') {
        for (int i = 0; i < 7; i++) {
          if (i >= 1) peso_aux[i - 1] = vector[i];
          digitalWrite(13, HIGH);
        }
        break; // when you find the correct value, stop the repetition
      }
    }
    delay(100);
  }

  // Return peso
  weight = String(peso_aux) + g;

  return weight;
}